package com.example.shstore.data

object UserSession {

    // id пользователя из auth.users (uuid)
    var userId: String? = null

    // access_token Supabase
    var accessToken: String? = null

    // email пользователя
    var email: String? = null

    // имя пользователя
    var name: String? = null
}